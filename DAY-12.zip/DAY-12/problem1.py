
'''find the frequency of array elements 1,2,3,4,4,3,2,1,1,1,2,2,3,3,4,4,
expected output 1-4,2-4,3-4,4-4'''



def count_frequencies(arr):
    freq={}
    for i in arr:
        freq[i]=freq.get(i,0)+1
    return freq

arr = [1,2,3,4,4,3,2,1,1,1,2,2,3,3,4,4]
frequencies=count_frequencies(arr)
for i, count in frequencies.items():
    print(i,count)


