
for i in range(1,5):
    for j in range(1,5):
        print(j+(i-1)*4,end="\t")
    print()

