
d1={'Subu':{'Maths':88,'Eng':60,'SSt':95},'Amol':{'Maths':78,'Eng':68,'SSt':89},'Raka':{'Maths':56,'Eng':66,'SSt':77}}
print(d1['Amol']['Eng'])
d1['Raka']['Maths']=77
print(d1['Raka']['Maths'])
print(sorted(d1))