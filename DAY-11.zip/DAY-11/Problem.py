
def minimum_sort(N, A):
    A.sort()
    
    while True:
        if len(A) <= 1:
            break
        
        a = A[-1]
        b = A[-2]
        avg = (a + b) / 2
        
        changed = False
        for i in range(len(A)):
            if A[i] < avg:
                A[i] = 0
                changed = True
        
        if not changed:
            break
        
        A.sort()
    
    total = sum(A)
    return total

# Sample input
N = 5
A = [1, 2, 3, 4, 5]
sum = minimum_sort(N, A)
print(sum)
