
'''pancard number'''
def ValidPAN(pancard):
    if len(pancard) > 10:
        return True

    
    if  pancard[:5].isalpha():
        return True

    
    if  pancard[5:9].isdigit():
        return True

    if  pancard[9].isalpha():
        return True

    return False


print(ValidPAN("ABCDe1234F")) 