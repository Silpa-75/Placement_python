
for i in range(4):
    for j in range(4):
        print("*",end=" ")
    print()
        
