data={
    'eth0':{'Ip':'1.1.1.1','Status':'UP'},
    'eth1':{'Ip':'2.2.2.2','Status':'UP'},
    'Wlan0':{'Ip':'3.3.3.3','Status':'Down'},
    'Wlan1':{'Ip':'4.4.4.4','Status':'UP'}
}

print(data.keys())

print(len(data))
