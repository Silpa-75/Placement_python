
'''You are given a function.
int CheckPassword(char str[], int n);
The function accepts string str of size n as an argument. Implement the function which returns 1 if given string str is valid password else 0.
str is a valid password if it satisfies the below conditions.

– At least 4 characters
– At least one numeric digit
– At Least one Capital Letter
– Must not have space or slash (/)
– Starting character must not be a number
Assumption:
Input string will not be empty.

Example:

Input 1:
aA1_67
Input 2:
a987 abC012

Output 1:
1
Output 2:
0 '''

def CheckPassword(str, n):
    # Check length
    if n < 4:
        return 0
    
    # Check if first character is a digit
    if str[0].isdigit():
        return 0

    has_digit = False
    has_capital = False

    for ch in str:
        if ch.isdigit():
            has_digit = True
        if ch.isupper():
            has_capital = True
        if ch == ' ' or ch == '/':
            return 0

    if has_digit and has_capital:
        return 1
    else:
        return 0

# Test cases
print(CheckPassword("aA1_67", 6))          # Expected 1
print(CheckPassword("a987 abC012", 12))    # Expected 0
print(CheckPassword("3abcD", 5))           # Expected 0
print(CheckPassword("abcD", 4))            # Expected 0
print(CheckPassword("ABCD", 4))            # Expected 0





