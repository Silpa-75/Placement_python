freq={}

def printRepeating(arr, n):
   
    
    for i in freq:
        if(freq[i] > 1):
            print(i, end=" ")



arr = [1,2,3,4,4]
n = len(arr)
printRepeating(arr,n)