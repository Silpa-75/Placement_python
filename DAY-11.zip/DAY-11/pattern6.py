
for i in range(4,0,-1):
    print("x"*i)