
'''
A 
A B 
A B C
A B C D
'''
for i in range(1, 5):
    for j in range(i):
        print(chr(65 + j), end=" ")
    print()
