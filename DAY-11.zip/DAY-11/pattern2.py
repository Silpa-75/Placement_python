
for row in range(4):
    for column in range(4):
        if(column==row):
            print("$",end=" ")
        else:
            print("*",end=" ")
    print()
        
    