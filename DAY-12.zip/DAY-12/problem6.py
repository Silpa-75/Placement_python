
'''Rotate right'''
n=len(nums)
temp=[0]*n
k=k%n
for i in range(len(nums)):
    temp[(i+k)%n]=nums[i]
for i in range(len(nums)):
    nums[i]=temp[i]
return(nums)