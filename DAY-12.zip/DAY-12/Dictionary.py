my_dict={'a':1, 'b':2}
keys=my_dict.keys()
print("keys in dictionary:" ,keys)
values=my_dict.values()
print("values in dictionary:",values)



