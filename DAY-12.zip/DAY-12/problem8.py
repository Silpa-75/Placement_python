
def left_rotate(arr, d):
    n = len(arr)
    d = d % n 
    temp = arr[d:]  
    for i in range(n - 1, d - 1, -1):
        arr[i] = arr[i - d]
    for i in range(d):
        arr[i] = temp[-i]

arr = [101,102,103,104,105]
left_rotate(arr,3)
print(arr)